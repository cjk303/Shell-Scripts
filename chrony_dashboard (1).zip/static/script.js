async function fetchTracking() {
    const res = await fetch('/api/tracking');
    const data = await res.json();

    const table = document.getElementById("tracking-table");
    table.innerHTML = '';
    for (let key in data) {
        const row = document.createElement('tr');
        row.innerHTML = `<td><strong>${key}</strong></td><td>${data[key]}</td>`;
        table.appendChild(row);
    }

    if (data['Root dispersion']) {
        const errorValue = parseFloat(data['Root dispersion'].split(' ')[0]);
        const time = new Date();

        Plotly.newPlot('error-graph', [{
            x: [time],
            y: [errorValue],
            type: 'scatter',
            mode: 'lines+markers',
            name: 'Root Dispersion (μs)',
        }], {
            margin: { t: 30 },
            xaxis: { title: 'Time' },
            yaxis: { title: 'Error (μs)' }
        });
    }
}

async function fetchClients() {
    const res = await fetch('/api/clients');
    const data = await res.json();

    const tableBody = document.querySelector("#clients-table tbody");
    tableBody.innerHTML = '';

    const ips = [], requests = [];

    data.forEach(client => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.ip}</td>
            <td>${client.nreq}</td>
            <td>${client.last_rx}</td>
        `;
        tableBody.appendChild(row);

        ips.push(client.ip);
        requests.push(parseInt(client.nreq));
    });

    Plotly.newPlot('clients-bar-chart', [{
        x: ips,
        y: requests,
        type: 'bar',
        name: 'NTP Requests'
    }], {
        title: 'NTP Requests per Client',
        margin: { t: 40 },
        xaxis: { title: 'Client IP' },
        yaxis: { title: 'Request Count' }
    });
}

fetchTracking();
fetchClients();
setInterval(() => {
    fetchTracking();
    fetchClients();
}, 10000);
