from flask import Flask, render_template, jsonify, Response
import subprocess
import re
import csv
from io import StringIO

app = Flask(__name__)

def run_chronyc_command(cmd):
    try:
        output = subprocess.check_output(['chronyc', cmd], stderr=subprocess.DEVNULL).decode()
        return output
    except Exception as e:
        return str(e)

def parse_tracking():
    output = run_chronyc_command('tracking')
    stats = {}
    for line in output.splitlines():
        parts = line.split(':', 1)
        if len(parts) == 2:
            key, value = parts
            stats[key.strip()] = value.strip()
    return stats

def parse_clients():
    output = run_chronyc_command('clients')
    clients = []
    for line in output.splitlines():
        if line.startswith("IP address") or line.strip() == "":
            continue
        parts = re.split(r'\s{2,}', line.strip())
        if len(parts) >= 3:
            clients.append({
                'ip': parts[0],
                'nreq': parts[1],
                'last_rx': parts[2]
            })
    return clients

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/tracking')
def tracking_data():
    return jsonify(parse_tracking())

@app.route('/api/clients')
def clients_data():
    return jsonify(parse_clients())

@app.route('/export/clients.csv')
def export_clients_csv():
    clients = parse_clients()
    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=["ip", "nreq", "last_rx"])
    writer.writeheader()
    writer.writerows(clients)
    response = Response(output.getvalue(), mimetype='text/csv')
    response.headers['Content-Disposition'] = 'attachment; filename=clients.csv'
    return response

if __name__ == '__main__':
    app.run(debug=True)
