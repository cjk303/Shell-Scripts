from flask import Flask, render_template
import plotly.graph_objs as go
import os
import subprocess
import psutil
import platform
import datetime

app = Flask(__name__)

CHRONY_LOG_DIR = "/var/log/chrony"

def parse_tracking():
    tracking_file = os.path.join(CHRONY_LOG_DIR, "tracking.log")
    if not os.path.exists(tracking_file):
        return []

    data = []
    with open(tracking_file, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 5:
                try:
                    timestamp = datetime.datetime.fromtimestamp(float(parts[0]))
                    offset = float(parts[1])
                    freq = float(parts[2])
                    data.append((timestamp, offset, freq))
                except ValueError:
                    continue
    return data

def plot_tracking(data):
    if not data:
        return None

    times = [d[0] for d in data]
    offsets = [d[1] for d in data]
    freqs = [d[2] for d in data]

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=times, y=offsets, name="Offset (us)", mode="lines"))
    fig.add_trace(go.Scatter(x=times, y=freqs, name="Frequency (ppm)", mode="lines"))
    fig.update_layout(
        title="Chrony Tracking",
        xaxis_title="Time",
        yaxis_title="Value",
        template="plotly_dark",
        autosize=True,
    )
    return fig.to_html(full_html=False)

def get_clients():
    try:
        output = subprocess.check_output(["chronyc", "clients"], text=True)
        return output.strip()
    except Exception as e:
        return f"Error getting clients: {e}"

def get_system_info():
    return {
        "hostname": platform.node(),
        "os": platform.platform(),
        "uptime": datetime.timedelta(seconds=int(float(open('/proc/uptime').read().split()[0]))),
        "cpu_usage": psutil.cpu_percent(),
        "memory": psutil.virtual_memory(),
        "disk": psutil.disk_usage('/'),
    }

@app.route("/")
def index():
    tracking_data = parse_tracking()
    chart_html = plot_tracking(tracking_data)
    clients = get_clients()
    sysinfo = get_system_info()
    return render_template("index.html", chart=chart_html, clients=clients, sysinfo=sysinfo, now=datetime.datetime.now())

if __name__ == "__main__":
    app.run(debug=True)
