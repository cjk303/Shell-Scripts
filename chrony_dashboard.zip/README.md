# Chrony Dashboard

A Flask web app that visualizes Chrony tracking data with a modern UI.

## Features

- Elegant Tailwind CSS UI
- Plotly charts for chrony tracking
- Chrony clients output
- System stats (uptime, CPU, memory, disk)
- Dark mode toggle

## Run

```bash
pip install flask plotly psutil
python app.py
```

Ensure you have access to `/var/log/chrony/tracking.log` and `chronyc clients`.
