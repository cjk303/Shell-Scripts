# Load MySQL .NET library
Add-Type -Path "$env:TEMP\mysql-connector\Assemblies\v4\MySql.Data.dll"

# MySQL connection info (replace with actual credentials)
$server = "your.mysql.host"
$database = "domainszones"
$user = "your_username"
$password = "your_password"
$connectionString = "server=$server;user id=$user;password=$password;database=$database;SslMode=Preferred"

# Open connection
$connection = New-Object MySql.Data.MySqlClient.MySqlConnection
$connection.ConnectionString = $connectionString
$connection.Open()

# Clear old data
$clearCmd = $connection.CreateCommand()
$clearCmd.CommandText = "TRUNCATE TABLE amer;"
$clearCmd.ExecuteNonQuery()

# Load Centrify module
Import-Module Centrify.DirectControl.PowerShell

# Get managed computers
$computers = Get-CdmManagedComputer

foreach ($computer in $computers) {
    $zoneName = "Unknown"
    if ($computer.Zone -match "CN=([^,]+)") {
        $zoneName = $matches[1]
    }

    $domainName = "Unknown"
    if ($computer.ScpPath -match "DC=") {
        try {
            $domainParts = ($computer.ScpPath -split ",") | Where-Object { $_ -like "DC=*" }
            $domainName = ($domainParts -replace "DC=") -join "."
        } catch {
            $domainName = "ParseError"
        }
    }

    $cmd = $connection.CreateCommand()
    $cmd.CommandText = "INSERT INTO amer (ComputerName, Zone, Domain) VALUES (@name, @zone, @domain);"
    $cmd.Parameters.Add((New-Object MySql.Data.MySqlClient.MySqlParameter("@name", $computer.Name))) | Out-Null
    $cmd.Parameters.Add((New-Object MySql.Data.MySqlClient.MySqlParameter("@zone", $zoneName))) | Out-Null
    $cmd.Parameters.Add((New-Object MySql.Data.MySqlClient.MySqlParameter("@domain", $domainName))) | Out-Null
    $cmd.ExecuteNonQuery()
}

$connection.Close()
Write-Host "✅ Data inserted into MySQL table 'amer'."
