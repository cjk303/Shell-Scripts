# Download and extract MySQL .NET Connector
$downloadUrl = "https://dev.mysql.com/get/Downloads/Connector-Net/mysql-connector-net-8.4.0.zip"
$zipPath = "$env:TEMP\mysql-connector.zip"
$extractPath = "$env:TEMP\mysql-connector"
$targetDll = "$extractPath\Assemblies\v4\MySql.Data.dll"

Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath
Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

if (-Not (Test-Path $targetDll)) {
    Write-Error "MySql.Data.dll not found after extraction."
    exit
}

Write-Host "✔ MySql.Data.dll ready at: $targetDll"
