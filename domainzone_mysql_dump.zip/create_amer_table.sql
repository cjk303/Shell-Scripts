CREATE TABLE IF NOT EXISTS amer (
    ComputerName VARCHAR(255),
    Zone VARCHAR(255),
    Domain VARCHAR(255)
);
