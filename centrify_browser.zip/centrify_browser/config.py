# config.py
DB_USER = "your_mysql_user"
DB_PASSWORD = "your_mysql_password"
DB_HOST = "localhost"
DB_NAME = "your_database"

SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}"
SQLALCHEMY_TRACK_MODIFICATIONS = False
