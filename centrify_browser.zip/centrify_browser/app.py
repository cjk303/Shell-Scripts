# app.py
from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
import config

app = Flask(__name__)
app.config.from_object(config)

db = SQLAlchemy(app)

class CentrifyComputer(db.Model):
    __tablename__ = 'centrify_computers'
    id = db.Column(db.Integer, primary_key=True)
    ComputerName = db.Column(db.String(255))
    Zone = db.Column(db.String(255))
    Domain = db.Column(db.String(255))

@app.route("/")
def index():
    search = request.args.get("search", "")
    query = CentrifyComputer.query
    if search:
        like = f"%{search}%"
        query = query.filter(
            (CentrifyComputer.ComputerName.ilike(like)) |
            (CentrifyComputer.Zone.ilike(like)) |
            (CentrifyComputer.Domain.ilike(like))
        )
    results = query.order_by(CentrifyComputer.ComputerName).all()
    return render_template("index.html", computers=results, search=search)

if __name__ == "__main__":
    app.run(debug=True)
